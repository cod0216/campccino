
package com.ssafy.campcino.service;

import com.ssafy.campcino.model.SidoEntity;
import java.util.List;

public interface SidoService {
    List<SidoEntity> getAllRegions();
}
