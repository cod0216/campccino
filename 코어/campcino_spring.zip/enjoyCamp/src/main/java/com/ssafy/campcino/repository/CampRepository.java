
package com.ssafy.campcino.repository;

import com.ssafy.campcino.model.CampDto;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
@Mapper
public interface CampRepository {
    List<CampDto> findAll();
    List<CampDto> getSelect(int region, int category, String text);
}
