package com.ssafy.campcino.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampDto {
    private int campId;             // 캠핑장 ID
    private int regionId;           // 지역 ID (추가된 필드)
    private int categoryId;         // 카테고리 ID
    private String campName;        // 캠핑장 이름
    private String campHomepage;    // 캠핑장 홈페이지
    private String campExplanation; // 캠핑장 설명
    private String campPhone;       // 캠핑장 전화번호
    private String campCharacter;   // 캠핑장 특징
    private double longitude;       // 경도
    private double latitude;        // 위도
    private String regionName;      // 지역 이름 (조인된 데이터)
    private String categoryName;    // 카테고리 이름 (조인된 데이터)
    private String roadAddress;     // 도로명 주소 (조인된 데이터)
    private String numberAddress;   // 지번 주소 (조인된 데이터)
}
