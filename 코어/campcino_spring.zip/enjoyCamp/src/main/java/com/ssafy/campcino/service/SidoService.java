
package com.ssafy.campcino.service;

import com.ssafy.campcino.model.SidoDto;
import java.util.List;

public interface SidoService {
    List<SidoDto> getAllRegions();
}
