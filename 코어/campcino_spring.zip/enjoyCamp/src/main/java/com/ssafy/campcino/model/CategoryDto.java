
package com.ssafy.campcino.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDto {
    private int categoryId;
    private String categoryName;

}
