
package com.ssafy.campcino.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SidoDto {
    private int sidoId;
    private String sidoName;

}
