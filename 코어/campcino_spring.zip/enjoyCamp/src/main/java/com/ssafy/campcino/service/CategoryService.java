
package com.ssafy.campcino.service;

import com.ssafy.campcino.model.CategoryDto;
import java.util.List;

public interface CategoryService {
    List<CategoryDto> getAllCategories();
}
