
package com.ssafy.campcino.controller;

import com.ssafy.campcino.model.*;
import com.ssafy.campcino.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CampController {

    @Autowired
    private CampService campService;

    @Autowired
    private AddressService addressService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private SidoService sidoService;

    // Camp endpoints
//    @GetMapping("/camps")
//    public List<CampDto> getAllCamps() {
//        return campService.getAllCamps();
//    }

    @GetMapping("/camps")
    public List<CampDto> getSelectCamps(
                                     @RequestParam(required = false, defaultValue = "0") int region,
                                     @RequestParam(required = false, defaultValue = "0") int category,
                                     @RequestParam(required = false, defaultValue = "") String text) {
        return campService.getSelectCamps(region, category, text);
    }

    // Address endpoints
    @GetMapping("/camps/{id}/address")
    public AddressDto getAddressByCampId(@PathVariable int id) {
        return addressService.getAddressByCampId(id);
    }

    // Category endpoints
    @GetMapping("/categories")
    public List<CategoryDto> getAllCategories() {
        return categoryService.getAllCategories();
    }

    // Region endpoints
    @GetMapping("/regions")
    public List<SidoDto> getAllRegions() {
        return sidoService.getAllRegions();
    }
}
