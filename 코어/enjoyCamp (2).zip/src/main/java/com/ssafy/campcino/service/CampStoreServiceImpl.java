package com.ssafy.campcino.service;

import com.ssafy.campcino.dto.responseDto.CampProductDto;
import com.ssafy.campcino.mapper.CampStoreMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CampStoreServiceImpl implements CampStoreService {

    @Autowired
    private CampStoreMapper campStoreMapper;

    @Override
    public List<CampProductDto> getAllCampProducts() {
        return campStoreMapper.findAllCampProducts();
    }

    @Override
    public CampProductDto getCampProductById(int productId) {
        return campStoreMapper.findCampProductById(productId);
    }
}
