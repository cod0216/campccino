package com.ssafy.campcino.controller;

import com.ssafy.campcino.dto.responseDto.CampProductDto;
import com.ssafy.campcino.service.CampStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/store")
public class CampStoreController {

    @Autowired
    private CampStoreService campStoreService;

    /**
     * 캠핑 용품 목록 조회
     * @return List<CampProductDto>
     */
    @GetMapping("/")
    public List<CampProductDto> getCampProducts() {
        System.out.println("checkout");
        return campStoreService.getAllCampProducts();
    }

    /**
     * 캠핑 용품 상세 조회
     * @param productId 캠핑 용품 ID
     * @return CampProductDto
     */
    @GetMapping("/{id}")
    public CampProductDto getCampProductById(@PathVariable("id") int productId) {
        return campStoreService.getCampProductById(productId);
    }
}
