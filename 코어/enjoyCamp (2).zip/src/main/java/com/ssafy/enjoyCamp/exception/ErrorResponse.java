package com.ssafy.enjoyCamp.exception;

public class ErrorResponse {
}
