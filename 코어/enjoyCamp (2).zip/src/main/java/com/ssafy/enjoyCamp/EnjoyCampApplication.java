package com.ssafy.enjoyCamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnjoyCampApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnjoyCampApplication.class, args);
	}

}
