package com.ssafy.enjoyCamp.controller;

public class BoardController {
}
