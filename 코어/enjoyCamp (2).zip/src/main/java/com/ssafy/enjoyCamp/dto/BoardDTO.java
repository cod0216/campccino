package com.ssafy.enjoyCamp.dto;

public class BoardDTO {
}
