package com.ssafy.campcino.dto.responseDto;

public class StoreDto {
    private int shopId;
    private String shopTitle;
    private long shopPrice;
    private String shopComment;
    private int productId;

    // Getters and Setters
}
