package com.ssafy.enjoyCamp.service;

public class CampService {
}
