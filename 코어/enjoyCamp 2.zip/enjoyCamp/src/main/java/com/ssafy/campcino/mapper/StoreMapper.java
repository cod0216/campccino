package com.ssafy.campcino.mapper;

import com.ssafy.campcino.dto.responseDto.StoreDto;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface StoreMapper {
    List<StoreDto> findAllStores();
    StoreDto findStoreById(int id);
}
