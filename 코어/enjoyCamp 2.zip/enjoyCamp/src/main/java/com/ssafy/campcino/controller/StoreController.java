package com.ssafy.campcino.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.campcino.dto.responseDto.StoreDto;
import com.ssafy.campcino.service.StoreService;

@RestController
@RequestMapping("/api/stores")
public class StoreController {

    @Autowired
    private StoreService storeService;

    // Store 목록 조회
    @GetMapping
    public List<StoreDto> getAllStores() {
        return storeService.getAllStores();
    }

    // 특정 Store 상세 정보 조회
    @GetMapping("/{id}")
    public StoreDto getStoreById(@PathVariable int id) {
        return storeService.getStoreById(id);
    }
}
