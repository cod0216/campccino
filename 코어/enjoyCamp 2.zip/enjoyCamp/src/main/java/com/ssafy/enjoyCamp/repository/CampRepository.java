package com.ssafy.enjoyCamp.repository;

public class CampRepository {
}
