package com.ssafy.enjoyCamp.exception;

public class CustomException {
}
