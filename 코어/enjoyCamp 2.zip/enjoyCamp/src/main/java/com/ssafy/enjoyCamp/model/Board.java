package com.ssafy.enjoyCamp.model;

public class Board {
}
