package com.ssafy.enjoyCamp.model;

public class User {
}
