
package com.ssafy.campcino.service;

import com.ssafy.campcino.model.CategoryEntity;
import java.util.List;

public interface CategoryService {
    List<CategoryEntity> getAllCategories();
}
