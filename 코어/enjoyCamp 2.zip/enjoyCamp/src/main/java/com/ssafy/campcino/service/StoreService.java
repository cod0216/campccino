package com.ssafy.campcino.service;

import java.util.List;

import com.ssafy.campcino.dto.responseDto.StoreDto;

public interface StoreService {
    List<StoreDto> getAllStores();
    StoreDto getStoreById(int id);
}
