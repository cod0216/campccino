package com.ssafy.campcino.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.campcino.dto.responseDto.StoreDto;
import com.ssafy.campcino.mapper.StoreMapper;

@Service
public class StoreServiceImpl implements StoreService {

    @Autowired
    private StoreMapper storeMapper;

    @Override
    public List<StoreDto> getAllStores() {
        return storeMapper.findAllStores();
    }

    @Override
    public StoreDto getStoreById(int id) {
        return storeMapper.findStoreById(id);
    }
}
