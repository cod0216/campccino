
package com.ssafy.campcino.repository;

import com.ssafy.campcino.model.SidoDto;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface SidoRepository {
    List<SidoDto> findAll();
}
