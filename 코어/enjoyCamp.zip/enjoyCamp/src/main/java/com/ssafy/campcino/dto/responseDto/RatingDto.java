package com.ssafy.campcino.dto.responseDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RatingDto {
    private int ratingId;
    private int productId;
    private double averageRating;
    private int totalReviews;
}