// src/stores/auth.js
import { defineStore } from "pinia";
import { loginUser, logoutUser, refreshToken } from "@/api";

export const useAuthStore = defineStore("auth", {
  state: () => ({
    isAuthenticated: false,
    user: null, // 사용자 정보
  }),
  actions: {
    async initializeAuth() {
      try {
        await refreshToken(); // 리프레시 토큰으로 상태 초기화
        this.isAuthenticated = true;
      } catch {
        this.isAuthenticated = false;
      }
    },
    async loginUser(credentials) {
      try {
        const response = await loginUser(credentials);
        this.isAuthenticated = true;
        this.user = response.data.user; // 서버에서 사용자 정보 가져오는 경우
      } catch (error) {
        const errorMessage = error.response?.data?.message || "로그인에 실패했습니다.";
        console.error("로그인 실패:", errorMessage);
        throw new Error(errorMessage);
      }
    },
    async logoutUser() {
      try {
        await logoutUser();
        this.isAuthenticated = false;
        this.user = null;
      } catch (error) {
        console.error("로그아웃 실패:", error);
        throw error;
      }
    },
    async refreshAccessToken() {
      try {
        await refreshToken();
        this.isAuthenticated = true;
      } catch (error) {
        console.error("토큰 갱신 실패:", error);
        this.isAuthenticated = false;
        throw error;
      }
    },
  },
});
