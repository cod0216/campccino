<template>
  <!-- Content for RatingStars.vue -->
  <div class="rating-stars">
    <span>별점 표시 컴포넌트</span>
  </div>
</template>

<script>
export default {
  name: "RatingStars",
};
</script>

<style scoped>
/* Add specific styles for RatingStars.vue here */
.rating-stars {
  color: #ffd700; /* 별점 색상 */
}
</style>
