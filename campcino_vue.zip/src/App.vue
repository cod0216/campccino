<!-- src/App.vue -->
<template>
  <router-view />
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
/* 필요에 따라 전역 스타일을 추가하세요 */
</style>
