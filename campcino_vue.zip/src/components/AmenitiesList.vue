<template>
  <!-- Content for AmenitiesList.vue -->
  <div class="amenities-list">
    <h2>편의시설 리스트</h2>
    <ul>
      <li>화장실</li>
      <li>샤워장</li>
      <li>전기 시설</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "AmenitiesList",
};
</script>

<style scoped>
/* Add specific styles for AmenitiesList.vue here */
.amenities-list {
  margin: 20px 0;
}
</style>
