<!-- src/components/PostItem.vue -->
<template>
  <div
    @click="navigateToPost"
    class="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2 justify-between border-b border-[#F4EFE6] cursor-pointer hover:bg-[#F9F9F9]"
  >
    <div class="flex items-center gap-4">
      <div
        class="text-[#1C160C] flex items-center justify-center rounded bg-[#F4EFE6] w-12 h-12"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          fill="currentColor"
          viewBox="0 0 256 256"
          class="w-6 h-6"
        >
          <path
            d="M228.92,49.69a8,8,0,0,0-6.86-1.45L160.93,63.52,99.58,32.84a8,8,0,0,0-5.52-.6l-64,16A8,8,0,0,0,24,56V200a8,8,0,0,0,9.94,7.76l61.13-15.28,61.35,30.68A8.15,8.15,0,0,0,160,224a8,8,0,0,0,1.94-.24l64-16A8,8,0,0,0,232,200V56A8,8,0,0,0,228.92,49.69ZM104,52.94l48,24V203.06l-48-24ZM40,62.25l48-12v127.5l-48,12Zm176,131.5-48,12V78.25l48-12Z"
          ></path>
        </svg>
      </div>
      <div class="flex flex-col justify-center">
        <p class="text-[#1C160C] text-base font-medium hover:underline">
          {{ post.board_title }}
        </p>
        <p class="text-[#A18249] text-sm font-normal line-clamp-2">
          {{ post.board_content }}
        </p>
      </div>
    </div>
    <div class="shrink-0">
      <p class="text-[#1C160C] text-base font-normal">
        {{ post.board_view }} views
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "BoardDetail",
  props: {
    post: {
      type: Object,
      required: true,
    },
  },
  methods: {
    navigateToPost() {
      this.$router.push({
        name: "BoardDetail",
        params: { id: this.post.board_id },
      });
    },
  },
};
</script>

<style scoped>
/* 필요에 따라 스타일을 추가하세요 */
</style>
