<template>
  <div>
    <Header />
    <h1 class="text-2xl font-bold mb-4">Store List</h1>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
      <div
        v-for="store in stores"
        :key="store.shopId"
        class="border p-4 rounded hover:shadow cursor-pointer"
        @click="viewStore(store.shopId)"
      >
        <h2 class="text-lg font-semibold">{{ store.shopTitle }}</h2>
        <p>Price: {{ store.shopPrice }}</p>
        <p>{{ store.shopComment }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import { useStoreStore } from "@/stores/storeStore";
import { onMounted } from "vue";
import Header from "@/components/Header.vue";

export default {
  name: "StoreListView",
  components: { Header },
  setup() {
    const storeStore = useStoreStore();

    onMounted(() => {
      storeStore.fetchStores();
    });

    return {
      stores: storeStore.stores,
      viewStore: (id) => {
        window.location.href = `/store/${id}`;
      },
    };
  },
};
</script>
