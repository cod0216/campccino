<template>
  <div>
    <Header />
    <div v-if="storeDetail" class="p-6">
      <h1 class="text-2xl font-bold">{{ storeDetail.shopTitle }}</h1>
      <p class="text-lg">Price: {{ storeDetail.shopPrice }}</p>
      <p class="mt-2">{{ storeDetail.shopComment }}</p>
    </div>
    <div v-else>
      <p>Loading store details...</p>
    </div>
  </div>
</template>

<script>
import { useStoreStore } from "@/stores/storeStore";
import { onMounted } from "vue";
import Header from "@/components/Header.vue";

export default {
  name: "StoreDetailView",
  components: { Header },
  setup() {
    const storeStore = useStoreStore();
    const storeId = parseInt(window.location.pathname.split("/").pop(), 10);

    onMounted(() => {
      storeStore.fetchStoreDetail(storeId);
    });

    return {
      storeDetail: storeStore.storeDetail,
    };
  },
};
</script>
