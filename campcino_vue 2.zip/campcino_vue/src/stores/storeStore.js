import { defineStore } from "pinia";
import axios from "@/plugins/axios";

export const useStoreStore = defineStore("storeStore", {
  state: () => ({
    stores: [], // Store 목록
    storeDetail: null, // 선택된 Store 상세 정보
  }),
  actions: {
    // 모든 Store 목록 가져오기
    async fetchStores() {
      try {
        const response = await axios.get("/stores");
        this.stores = response.data;
      } catch (error) {
        console.error("Error fetching stores:", error);
      }
    },
    // 특정 Store 상세 정보 가져오기
    async fetchStoreDetail(storeId) {
      try {
        const response = await axios.get(`/stores/${storeId}`);
        this.storeDetail = response.data;
      } catch (error) {
        console.error("Error fetching store detail:", error);
      }
    },
  },
});
